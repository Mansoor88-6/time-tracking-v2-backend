# Extension Icons

Place icon files here:
- icon16.png (16x16 pixels)
- icon48.png (48x48 pixels)
- icon128.png (128x128 pixels)

You can create simple icons or use placeholder images for development.
